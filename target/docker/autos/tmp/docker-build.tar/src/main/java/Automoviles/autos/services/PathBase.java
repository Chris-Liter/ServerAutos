package Automoviles.autos.services;

//import org.eclipse.microprofile.openapi.annotations.OpenAPIDefinition;
//import org.eclipse.microprofile.openapi.annotations.info.Info;

//import org.eclipse.microprofile.openapi.annotations.OpenAPIDefinition;
//import org.eclipse.microprofile.openapi.annotations.info.Info;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

/*@ApplicationPath("rs")
@OpenAPIDefinition(info = @Info(
		title = "Hello World MicroProfile",
		description = "API de muestra Hello World MicroProfile", version = "1.0.0"))*/

public class PathBase{

	
}
